package com.gorondin.badminton;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.text.TextUtils;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String URL = "https://jadwalonbc.blogspot.com/";
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    /** Bridge used by the website share button when WebView does not expose navigator.share(). */
    public class AndroidShareBridge {
        @JavascriptInterface
        public void share(String title, String text, String url) {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            if (!TextUtils.isEmpty(text)) send.putExtra(Intent.EXTRA_TEXT, text + (TextUtils.isEmpty(url) ? "" : "\n" + url));
            else if (!TextUtils.isEmpty(url)) send.putExtra(Intent.EXTRA_TEXT, url);
            if (!TextUtils.isEmpty(title)) send.putExtra(Intent.EXTRA_TITLE, title);
            try {
                startActivity(Intent.createChooser(send, TextUtils.isEmpty(title) ? "Bagikan jadwal" : title));
            } catch (ActivityNotFoundException e) {
                Toast.makeText(MainActivity.this, "Tidak ada aplikasi untuk membagikan jadwal", Toast.LENGTH_SHORT).show();
            }
        }

        @JavascriptInterface
        public void shareFile(String title, String text, String mime, String filename, String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                String safeName = TextUtils.isEmpty(filename) ? "jadwal-gor-ondin.png" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }

                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(TextUtils.isEmpty(mime) ? "image/png" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (!TextUtils.isEmpty(text)) send.putExtra(Intent.EXTRA_TEXT, text);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { send.setClipData(ClipData.newRawUri("jadwal", uri)); } catch (Exception ignored) {}
                startActivity(Intent.createChooser(send, TextUtils.isEmpty(title) ? "Bagikan jadwal" : title));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal menyiapkan jadwal untuk dibagikan", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Allow pinch/double-tap zoom even if the website sets a restrictive viewport.
                view.evaluateJavascript("(function(){" +
                        "var m=document.querySelector('meta[name=\"viewport\"]');" +
                        "if(m){m.setAttribute('content','width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=5, user-scalable=yes');}" +
                        "if(window.AndroidShare){" +
                        "window.navigator.share=function(data){data=data||{};" +
                        "if(data.files&&data.files.length){" +
                        "var f=data.files[0];" +
                        "f.arrayBuffer().then(function(buf){var bytes=new Uint8Array(buf),bin='';for(var i=0;i<bytes.length;i++){bin+=String.fromCharCode(bytes[i]);}" +
                        "var b64=btoa(bin);window.AndroidShare.shareFile(String(data.title||''),String(data.text||''),String(f.type||'application/octet-stream'),String(f.name||'jadwal-gor-ondin'),b64);" +
                        "});" +
                        "}else{window.AndroidShare.share(String(data.title||''),String(data.text||''),String(data.url||''));}" +
                        "return Promise.resolve();};" +
                        "}" +
                        "})();", null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                // Open WhatsApp/other external share links in their native app when possible.
                if (url.startsWith("whatsapp://") || url.startsWith("intent:") ||
                        host.equals("wa.me") || host.endsWith(".wa.me") ||
                        host.equals("api.whatsapp.com") || host.equals("chat.whatsapp.com")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored2) {}
                    }
                    return true;
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {}
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            // Support JavaScript dialogs used by the website (for example
            // confirm("Hapus member?")) inside Android WebView.
            @Override
            public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setText(defaultValue == null ? "" : defaultValue);
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm(input.getText().toString()))
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), 1001);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.loadUrl(URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack();
                else finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
}
