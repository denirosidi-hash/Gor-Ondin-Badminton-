package com.gorondin.badminton;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.text.TextUtils;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final String URL = "https://jadwalonbc.blogspot.com/";
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;

    /** Bridge used by the website share button. Large JPG files are sent in chunks
     * so Android's Binder/JavaScript bridge is not overloaded by one huge Base64 string. */
    public class AndroidShareBridge {
        private FileOutputStream pendingOutput;
        private File pendingFile;
        private String pendingTitle;
        private String pendingText;
        private String pendingMime;

        @JavascriptInterface
        public synchronized void share(String title, String text, String url) {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            String body = !TextUtils.isEmpty(text) ? text : "";
            if (!TextUtils.isEmpty(url)) body += (body.isEmpty() ? "" : "\n") + url;
            send.putExtra(Intent.EXTRA_TEXT, body);
            if (!TextUtils.isEmpty(title)) send.putExtra(Intent.EXTRA_TITLE, title);
            launchChooser(send, title);
        }

        @JavascriptInterface
        public synchronized void startShareFile(String title, String text, String mime, String filename) {
            try {
                closePendingQuietly();
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                String safeName = TextUtils.isEmpty(filename) ? "jadwal-gor-ondin.jpg" :
                        filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                if (!safeName.contains(".")) {
                    safeName += TextUtils.isEmpty(mime) ? ".jpg" : (mime.contains("png") ? ".png" : ".jpg");
                }
                pendingFile = new File(dir, safeName);
                pendingOutput = new FileOutputStream(pendingFile, false);
                pendingTitle = title;
                pendingText = text;
                pendingMime = TextUtils.isEmpty(mime) ? "image/jpeg" : mime;
            } catch (Exception e) {
                closePendingQuietly();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Gagal menyiapkan gambar jadwal", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public synchronized void appendShareFileChunk(String base64Chunk) {
            try {
                if (pendingOutput == null) return;
                byte[] bytes = Base64.decode(base64Chunk, Base64.DEFAULT);
                pendingOutput.write(bytes);
            } catch (Exception e) {
                closePendingQuietly();
            }
        }

        @JavascriptInterface
        public synchronized void finishShareFile() {
            try {
                if (pendingOutput == null || pendingFile == null) return;
                pendingOutput.flush();
                pendingOutput.close();
                pendingOutput = null;

                Uri uri = FileProvider.getUriForFile(MainActivity.this,
                        getPackageName() + ".fileprovider", pendingFile);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(TextUtils.isEmpty(pendingMime) ? "image/jpeg" : pendingMime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                if (!TextUtils.isEmpty(pendingText)) send.putExtra(Intent.EXTRA_TEXT, pendingText);
                if (!TextUtils.isEmpty(pendingTitle)) send.putExtra(Intent.EXTRA_TITLE, pendingTitle);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                send.setClipData(ClipData.newRawUri("jadwal-gor-ondin", uri));
                grantUriPermissions(send, uri);
                launchChooser(send, pendingTitle);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Gagal membuka menu Share gambar", Toast.LENGTH_SHORT).show());
            } finally {
                pendingFile = null;
                pendingTitle = null;
                pendingText = null;
                pendingMime = null;
            }
        }

        // Kept for compatibility with older injected code.
        @JavascriptInterface
        public void shareFile(String title, String text, String mime, String filename, String base64) {
            startShareFile(title, text, mime, filename);
            appendShareFileChunk(base64);
            finishShareFile();
        }

        private void grantUriPermissions(Intent send, Uri uri) {
            try {
                android.content.pm.PackageManager pm = getPackageManager();
                java.util.List<android.content.pm.ResolveInfo> receivers =
                        pm.queryIntentActivities(send, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
                for (android.content.pm.ResolveInfo info : receivers) {
                    if (info.activityInfo != null && info.activityInfo.packageName != null) {
                        grantUriPermission(info.activityInfo.packageName, uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    }
                }
            } catch (Exception ignored) {}
        }

        private void launchChooser(Intent send, String title) {
            Runnable action = () -> {
                try {
                    Intent chooser = Intent.createChooser(send,
                            TextUtils.isEmpty(title) ? "Bagikan jadwal" : title);
                    chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(chooser);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this,
                            "Tidak ada aplikasi untuk membagikan jadwal", Toast.LENGTH_SHORT).show();
                }
            };
            if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) action.run();
            else runOnUiThread(action);
        }

        private void closePendingQuietly() {
            try { if (pendingOutput != null) pendingOutput.close(); } catch (Exception ignored) {}
            pendingOutput = null;
            pendingFile = null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidShareBridge(), "AndroidShare");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Allow pinch/double-tap zoom and provide a native Android share bridge.
                view.evaluateJavascript("(function(){" +
                        "var m=document.querySelector('meta[name=\"viewport\"]');" +
                        "if(m){m.setAttribute('content','width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=5, user-scalable=yes');}" +
                        "if(window.AndroidShare){" +
                        "window.navigator.canShare=function(){return true;};" +
                        "window.navigator.share=function(data){data=data||{};" +
                        "if(data.files&&data.files.length){" +
                        "var f=data.files[0],reader=new FileReader();" +
                        "reader.onload=function(){var result=reader.result||'',comma=result.indexOf(',');var b64=comma>=0?result.substring(comma+1):result;" +
                        "window.AndroidShare.startShareFile(String(data.title||''),String(data.text||''),String(f.type||'image/jpeg'),String(f.name||'jadwal-gor-ondin.jpg'));" +
                        "var step=32768;for(var i=0;i<b64.length;i+=step){window.AndroidShare.appendShareFileChunk(b64.substring(i,Math.min(i+step,b64.length)));}" +
                        "window.AndroidShare.finishShareFile();};" +
                        "reader.onerror=function(){window.AndroidShare.share(String(data.title||''),String(data.text||''),String(data.url||''));};" +
                        "reader.readAsDataURL(f);" +
                        "}else{window.AndroidShare.share(String(data.title||''),String(data.text||''),String(data.url||''));}" +
                        "return Promise.resolve();};" +
                        "}" +
                        "})();", null);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                // Open WhatsApp/other external share links in their native app when possible.
                if (url.startsWith("whatsapp://") || url.startsWith("intent:") ||
                        host.equals("wa.me") || host.endsWith(".wa.me") ||
                        host.equals("api.whatsapp.com") || host.equals("chat.whatsapp.com")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored2) {}
                    }
                    return true;
                }
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    view.loadUrl(url);
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {}
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            // Support JavaScript dialogs used by the website (for example
            // confirm("Hapus member?")) inside Android WebView.
            @Override
            public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, android.webkit.JsPromptResult result) {
                final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
                input.setSingleLine(true);
                input.setText(defaultValue == null ? "" : defaultValue);
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm(input.getText().toString()))
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), 1001);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.loadUrl(URL);

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack();
                else finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    results = new Uri[n];
                    for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(results);
            fileCallback = null;
        }
    }
}
