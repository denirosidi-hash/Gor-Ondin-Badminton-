VERSI BUILD APK DENGAN 1 TOMBOL DARI HP

Setelah project ini diunggah ke GitHub:
1. Buka repository GitHub dari HP.
2. Buka tab Actions.
3. Pilih workflow "Build APK".
4. Tekan "Run workflow".
5. Tunggu proses selesai.
6. Buka hasil workflow tersebut.
7. Download artifact "GOR-ONDIN-BADMINTON-APK".
8. Ekstrak ZIP artifact, lalu install APK di HP.

Workflow menggunakan GitHub Actions + Gradle untuk mengompilasi APK.
Tidak perlu Android Studio di HP.
