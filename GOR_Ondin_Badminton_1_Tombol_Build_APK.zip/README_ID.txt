GOR ONDIN BADMINTON - PROJECT APK

Website yang dibuka:
https://jadwalonbc.blogspot.com/

Cara membuat APK:
1. Buka project ini dengan Android Studio versi terbaru.
2. Tunggu Gradle selesai melakukan Sync.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug biasanya berada di:
   app/build/outputs/apk/debug/app-debug.apk

Nama aplikasi:
GOR ONDIN BADMINTON

Package:
com.gorondin.badminton

Catatan:
- Aplikasi ini menggunakan WebView sehingga sistem website, login Firebase,
  jadwal, booking, pembayaran, dan menu yang ada di website tetap digunakan.
- Internet diperlukan karena website dan Firebase diakses secara online.
- Tombol Back Android mengikuti riwayat halaman WebView.
- File chooser dasar sudah disiapkan.
